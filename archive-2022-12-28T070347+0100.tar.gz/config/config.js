module.exports = {

  Prefix: ";", 
  unqualifiedID: '1044111604402376804',// ID
  ass: '1030004213465481266',// ID
  approvedID: '1035247853339168820',//ID Of channel
  exit: '1041343756382773248',//ID Of channel
  email: "",//COC Email
	password: "",//COC Password
  //
app:'1035991027368067092',
unq:'1044120594012180590',
nc: '1030004193307656263',
  Users: {
    OWNERS: ["506354776586452992"] 
  },
  Client: {
    TOKEN: "",
     ID: "1037706329378259004" 
  },
r :{
    'member': 'Member',
    'coLeader': 'Co-Leader',
    'leader': 'Leader',
    'elder': 'Elder',
    'null': '-',

   },
  townhallE: {
    '15': '<:TH15:1057509514024337428>',
    '14': '<:TH14:1057506542745821235>',
    '13': '<:TH13:1057506540258607154>',
    '12': '<:TH12:1057506545698623648>',
    '11': '<:TH11:1057506537695883284>',
    '10': '<:TH10:1057506534617256017>',
    '9': '<:TH9:1057506532264247366>',
    '8': '<:TH8:1057506529617645568>',
    '7': '<:TH7:1057506526559997982>',
    '6': '<:TH6:1057506523993088101>',
    '5': '<:TH5:1057506561767002192>',
    '4': '<:TH4:1057506559036506192>',
    '3': '<:TH3:1057506556310204416>',
    '2': '<:TH2:1057506553881702461>',
    '1': '<:TH1:1057506551285428255>',
  },
 lemoji : {
'Legend League'  :'<:legendleague:1039734414143389797>',
'Titan League III' :'<:titan_league:1039734425652559932>',
'Titan League II' :'<:titan_league:1039734425652559932>',
'Titan League I' :'<:titan_league:1039734425652559932>',
'Champion League III' :'<:championleague:1039734471781519481>',
'Champion League II' :'<:championleague:1039734471781519481>',
'Champion League I' :'<:championleague:1039734471781519481>',
'Master League III' :'<:masterleague:1039734417335275570>',
'Master League II' :'<:masterleague:1039734417335275570>',
'Master League I' :'<:masterleague:1039734417335275570>',
'Crystal League III' :'<:crystalleague:1039734404194504704>',
'Crystal League II' :'<:crystalleague:1039734404194504704>',
'Crystal League I' :'<:crystalleague:1039734404194504704>',
'Gold League III' :'<:goldleague:1039734407189245953>' ,
'Gold League II' :'<:goldleague:1039734407189245953>' ,
'Gold League I' :'<:goldleague:1039734407189245953>' ,
'Silver League III' :'<:silver_league:1039734423119200346>',
'Silver League II' :'<:silver_league:1039734423119200346>',
'Silver League I' :'<:silver_league:1039734423119200346>',
'Bronze League III':'<:bronzeleague:1039734468941975582>',
'Bronze League II':'<:bronzeleague:1039734468941975582>',
'Bronze League I':'<:bronzeleague:1039734468941975582>',
'Unranked' :'<:unranked_league:1039734428466942013>',
},
townhallW: {
  '5': '⁵',
  '4': '⁴',
  '3': '³',
  '2': '²',
  '1': '¹',
  'null': '',
},
}
