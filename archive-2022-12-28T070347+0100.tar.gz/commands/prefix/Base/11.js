const { EmbedBuilder } = require("discord.js"); 

module.exports = {
  config: {
    name: "11",
    description: "Send TH 11 FWA BASE",
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {

   await message.channel.send({ embeds: [
                new EmbedBuilder()
                .setDescription(`<a:Diamond:1035887938627719210> 𝗙𝗪𝗔 𝗕𝗔𝗦𝗘 𝗙𝗢𝗥 𝗧𝗢𝗪𝗡𝗛𝗔𝗟𝗟 ${config.townhallE[11]}:- \n\n<a:K_king:1037956418550116393> We would recommend copying the below FWɑ Bɑse lɑyout into your wɑr bɑse slot. \n\n<a:amar:1035945306245832714> [𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘 𝗙𝗢𝗥 𝗙𝗪𝗔 𝗕𝗔𝗦𝗘 𝗟𝗜𝗡𝗞](https://link.clashofclans.com/en?action=OpenLayout&id=TH11%3AWB%3AAAAASgAAAAGSR_nQJ7f0DMJCHu2KNJm3)\n\n<a:important:1039004082859409461> 𝙆𝙚𝙚𝙥 𝙞𝙣 𝙢𝙞𝙣𝙙 𝙩𝙝𝙖𝙩 𝙖 𝙣𝙚𝙬 𝙗𝙖𝙨𝙚 𝙞𝙨 𝙧𝙚𝙦𝙪𝙞𝙧𝙚𝙙 𝙬𝙝𝙚𝙣 𝙮𝙤𝙪 𝙞𝙣𝙘𝙧𝙚𝙖𝙨𝙚 𝙮𝙤𝙪𝙧 𝙩𝙤𝙬𝙣𝙝𝙖𝙡𝙡 𝙡𝙚𝙫𝙚𝙡 <a:j_important:1039005520062853130>`)
                .setColor('#f5f5f5')
                .setImage('https://media.discordapp.net/attachments/1036981585150484481/1037962417751207946/BAND_The_Phoenix_Odyssey_2022-11-04-105644_03.jpg?width=788&height=591')
                .setFooter( {
                    text: `◤ 𝗝𝗣𝗔 ◢ - 💎𝗙𝗪𝗔💎`
                })
    ]
     })
    
  },
};