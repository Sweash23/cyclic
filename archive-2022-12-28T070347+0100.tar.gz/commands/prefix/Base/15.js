const { EmbedBuilder, Message } = require("discord.js"); 

module.exports = {
  config: {
    name: "15",
    description: "Send TH 15 FWA BASE",
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {

   await message.channel.send({ embeds: [
                new EmbedBuilder()
                .setDescription(`<a:Diamond:1035887938627719210> 𝗙𝗪𝗔 𝗕𝗔𝗦𝗘 𝗙𝗢𝗥 𝗧𝗢𝗪𝗡𝗛𝗔𝗟𝗟 ${config.townhallE[15]}:- \n\n<a:K_king:1037956418550116393> We would recommend copying the below FWɑ Bɑse lɑyout into your wɑr bɑse slot. \n\n<a:amar:1035945306245832714> [CLICK HERE FOR FWA BASE LINK](https://link.clashofclans.com/en?action=OpenLayout&id=TH15%3AWB%3AAAAAGQAAAAIaJOyMSYl3n-SRiDpTc2d5)\n\n<a:important:1039004082859409461> 𝙆𝙚𝙚𝙥 𝙞𝙣 𝙢𝙞𝙣𝙙 𝙩𝙝𝙖𝙩 𝙖 𝙣𝙚𝙬 𝙗𝙖𝙨𝙚 𝙞𝙨 𝙧𝙚𝙦𝙪𝙞𝙧𝙚𝙙 𝙬𝙝𝙚𝙣 𝙮𝙤𝙪 𝙞𝙣𝙘𝙧𝙚𝙖𝙨𝙚 𝙮𝙤𝙪𝙧 𝙩𝙤𝙬𝙣𝙝𝙖𝙡𝙡 𝙡𝙚𝙫𝙚𝙡 <a:j_important:1039005520062853130>`)
                .setColor('#6513d1')
                .setImage('https://media.discordapp.net/attachments/1038003033893765150/1038003523973042207/TH15.png')
                .setFooter( {
                    text: `◤ 𝗝𝗣𝗔 ◢ - 💎𝗙𝗪𝗔💎`
                })
    ]
     })
    
  },
};