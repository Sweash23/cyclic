const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js"); 
const { HTTPError, Util, Client } = require('clashofclans.js');
const coc = new Client();



module.exports = {
  config: {
    name: "c",
    description: "check cc of clan",
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {

    const warStates = {
      preparation: 'Preparation day',
      inWar: 'Battle day',
      warEnded: 'War ended',
      privateWarLog: 'Private'
    };
   let tag = args[0];
    if (!tag) {
      return message.reply({
            content:
                "You need to provide Player Tag",
            ephemeral: true
        });
    } else if (!Util.isValidTag(Util.formatTag(tag))) {
      return message.reply({ content: `${tag} isn't a valid player tag!`, ephemeral: true });
}

    (async function () {
          await coc.login({ email: process.env.email, password: process.env.password });
             let clanTag = args[0];
    if (!clanTag) {
      return message.reply({
            content:
                "You need to provide Clan Tag",
            ephemeral: true
        });
    } else if (!Util.isValidTag(Util.formatTag(clanTag))) {
      return message.reply({ content: `${clanTag} isn't a valid Clan tag!`, ephemeral: true });
}
    const clan = await coc.getClan(clanTag);
  //  const war = await coc.getClanWar(clanTag) !== NotInWarError;
try {
  await message.channel.send({ embeds: [
  new EmbedBuilder()
  .setTitle(`${clan.name} (${clan.tag})`)
  .setDescription(`\=== Clan Info ===\n\n<a:izkdot:1039755736999276654> Leader: ${clan.members.find((member) => member.role === 'leader').name} \n<a:izkdot:1039755736999276654> Member: ${clan.memberCount}\n<a:izkdot:1039755736999276654> Location: ${clan.location?.name ?? 'Not set'}\n\n<a:fwa:1037968348828409866> [𝗖𝗵𝗼𝗰𝗼𝗹𝗮𝘁𝗲 𝗖𝗹𝗮𝘀𝗵 𝗟𝗶𝗻𝗸](https://fwa.chocolateclash.com/cc_n/clan.php?tag=${clan.tag.replaceAll('#', '')}) \n\n<:clash_of_clans_logo:886960455044718612> [𝐂𝐥𝐚𝐬𝐡 𝐨𝐟 𝐒𝐭𝐚𝐭𝐬](https://www.clashofstats.com/clans/${clan.tag.replaceAll('#', '')}/summary)\n\n◤ 𝗝𝗣𝗔 ◢ - 💎𝗙𝗪𝗔💎`)
 
  .setColor('44d4db') 
  .setURL(`https://link.clashofclans.com/en?action=OpenClanProfile&tag=${clan.tag.replaceAll('#', '')}`)
],
components: [
  new ActionRowBuilder()
      .addComponents(
          new ButtonBuilder()
              .setURL(`https://link.clashofclans.com/en?action=OpenClanProfile&tag=${clan.tag.replaceAll('#', '')}`)
              .setLabel('Join here!')
              .setStyle(ButtonStyle.Link)
              .setEmoji('<:Clan_Castle10:1050401327513075802>')
              .setDisabled(false) // Not public
      )
      .addComponents(
        new ButtonBuilder()
            .setURL(`https://points.fwa.farm/result.php?clan=${clan.tag.replaceAll('#', '')}`)
            .setLabel('point of clan!')
            .setStyle(ButtonStyle.Link)
            .setEmoji('<a:clan:1050401660553408612>')
            .setDisabled(false) // Not public
    )
]
})
} catch (error) {
      console.error(error);
      await message.reply({ content: 'Something went wrong, try again!' });
}

    })();
}
};