const { EmbedBuilder } = require("discord.js"); 
const { Client, HTTPError , Util  } = require('clashofclans.js');
const coc = new Client();

module.exports = {
  config: {
    name: "app",
    description: "The bot will send an approval message and add a position for users who are eligible.",
  },
  permissions: ['ManageRoles'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {

    let playerTags = args[0].split(' ');
    async function fetchData(playerTags) {
          await coc.login({ email: process.env.email, password: process.env.password });
          const player = await coc.getPlayer(playerTags);
          return [
            player.name, player.townHallLevel
          ]
        };
     try{
      const target = await message.mentions.members.first();
      const townhallR = {
        '15': 'TH15',
        '14': 'TH14',
        '13': 'TH13',
        '12': 'TH12',
        '11': 'TH11',
        '10': 'TH10'
      };
      const playerData = await fetchData(playerTags[0]);
      const villageName = playerData[0];
      const thlvlR = townhallR[playerData[1]];
      

       let ole = message.guild.roles.cache.find(r => r.id === config.unq);
       let le = message.guild.roles.cache.find(r => r.id === config.nc);
       let e = message.guild.roles.cache.find(r => r.id === config.app);
if (!target) return message.channel.send (`Sorry no user found to 𝐚𝐩𝐩𝐫𝐨𝐯𝐞\n Please use ${prefix}app <playertag> <@user>`)
await target.roles.remove(ole);
await target.roles.remove(le); 
await target.roles.add(e);

await target.setNickname(`${thlvlR} - ${villageName}`);
message.delete()
const channel = await client.channels.fetch(config.approvedID, { force: false });
if (!channel) {
 return;
}

const b = new EmbedBuilder()
.setColor('#44d4db')
.setFooter( {
  text: `JPA - 💎FWA💎`
})
.setDescription (`<a:welcome:1039755758969028739> Welcome to <#1035247853339168820>\n\n<a:dot:1039755771744886834>This is where you will find spaces in our <#1035871505998958593>.\n<a:dot:1039755771744886834>You will be @mentioned when there is a spot open for you.\n<a:dot:1039755771744886834>You can stay in your current clan if needed.\n<a:dot:1039755771744886834>If any questions please ask here.\n<a:dot:1039755771744886834>Feel free to talk in <#1030004213465481266>.\n\nThank you and good day <a:ffxclan:1039755734356869170>.`)

await channel.send({ content: `Hey ${target}` ,embeds: [b], ephemeral: false});
     }catch (error) {
      console.log(error);
    }
}
};
