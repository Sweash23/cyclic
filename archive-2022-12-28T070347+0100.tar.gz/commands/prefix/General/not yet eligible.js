const { EmbedBuilder } = require("discord.js"); 
const { Client, HTTPError , Util  } = require('clashofclans.js');
const coc = new Client();

module.exports = {
  config: {
    name: "unq",
    description: "Not yet eligible",
  },
  permissions: ['ManageRoles'], 
  owner: false,
  run: async (client, message, args, prefix, config, db) => {

    let playerTags = args[0].split(' ');
    async function fetchData(playerTags) {
          await coc.login({ email: process.env.email, password: process.env.password });
          const player = await coc.getPlayer(playerTags);
          return [
            player.name, player.townHallLevel
          ]
        };
     try{
      const target = await message.mentions.members.first();
      const playerData = await fetchData(playerTags[0]);
      const villageName = playerData[0];
      if (!target) return message.channel.send (`Sorry no user found to 𝐮𝐧𝐚𝐩𝐩𝐫𝐨𝐯𝐞\n Please use ${prefix}app <playertag> <@user>`)     
 let ole = message.guild.roles.cache.find(r => r.id === config.unq);
 let le = message.guild.roles.cache.find(r => r.id === config.nc);
 let e = message.guild.roles.cache.find(r => r.id === config.app);
 
 await target.roles.remove(le);
 await target.roles.remove(e); 
 await target.roles.add(ole);

 target.setNickname(`UQ - ${villageName}`);

 message.delete()
 const channel = await client.channels.fetch(config.unqualifiedID, { force: false });
 if (!channel) {
     return;
 }
 const b = new EmbedBuilder()
.setColor('#44d4db')
.setFooter( {
  text: `JPA - 💎FWA💎`
})
.setDescription(`𝗧𝗵𝗶𝘀 𝗶𝘀 <#1044111604402376804> room. 𝗬𝗼𝘂'𝗿𝗲 𝗵𝗲𝗿𝗲 𝗯𝗲𝗰𝗮𝘂𝘀𝗲 :-\n\n<a:dots:1044176156900982794>You might not be meeting up our minimum requirements (Please type !req to know our minimum requirements for joining a clan).\n<a:dots:1044176156900982794>You might have been lurking around in <#1036318990680723557> or <#1035247853339168820> room without any activity.\n<a:dots:1044176156900982794>You might have left the clan without intimating us.\n<a:dots:1044176156900982794>You might have dropped out of clan due to inactivity/deviating from rules/or exceeding the minimum set strike points.\n\n<a:flex_hashtag:1044175480212967505> Please Do type !apply and follow the steps if you wish to join.`)
await channel.send({ content: `Hey ${target}` ,embeds: [b], ephemeral: false});

  }catch (error) {
    console.log(error);
  }
  },
};
