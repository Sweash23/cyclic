const { EmbedBuilder, Message } = require("discord.js"); 

module.exports = {
  config: {
    name: "base",
    description: "Send FWA BASE GUIDELINES",
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {

    const b = new EmbedBuilder()
    .setColor('DarkButNotBlack')
    .setFooter( {
      text: `◤ 𝗝𝗣𝗔 ◢ - 💎𝗙𝗪𝗔💎`
  })
  .setDescription (`To know the guidelines of 𝔽𝕎𝔸 𝔹𝕒𝕤𝕖 :-\n\n➜[「𝗖𝗟𝗜𝗖𝗞 𝗛𝗘𝗥𝗘 𝗙𝗢𝗥 𝗚𝗨𝗜𝗗𝗘𝗟𝗜𝗡𝗘𝗦」](http://tiny.cc/FWABaseGuide)\n\n <a:SC_Point:1051709557157658644> **Please type the below command to fetch the following information** : \n\n<:TH15:1037990282794381362> \`${prefix}15\` - For **Th15** FWA Base link.\n<:TH14:1037990523731968020> \`${prefix}14\` - For **Th14** FWA Base link.\n<:TH13:1037990727197655120> \`${prefix}13\` - For **Th13** FWA Base link.\n<:TH12:1037983826628071454> \`${prefix}12\` - For **Th12** FWA Base link.\n<:TH11:1037990918604718112> \`${prefix}11\` - For **Th11** FWA Base link.\n<:Th10:1037989986722644008> \`${prefix}10\` - For **Th10** FWA Base link.`)
    message.reply({ content: `<:ship:1051703574385676299>**Base commands** :-` ,embeds: [b], ephemeral: false});
    
  },
};