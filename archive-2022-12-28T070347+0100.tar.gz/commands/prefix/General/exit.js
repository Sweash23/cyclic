const { EmbedBuilder } = require("discord.js"); 
const { Client, HTTPError , Util  } = require('clashofclans.js');

const coc = new Client();

module.exports = {
  config: {
    name: "ex",
    description: "If a user leaves the game, then using this command bot, his role will be removed and a message with the reason will be sent.",
  },
  permissions: ['ManageRoles'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {
    const embed1 = new EmbedBuilder()
    .setDescription("Please mention the user.")
    .setColor('#44d4db')

  const embed2 = new EmbedBuilder()
    .setDescription("Please provide the reason.")
    .setColor('#44d4db')

    const t = new EmbedBuilder()
    .setDescription("Please provide the tag of player.")
    .setColor('#44d4db')
    const channel = await client.channels.fetch(config.exit, { force: false });
    if (!channel) {
     return;
    }
    const playerTags = args[0].split(' ');
    if (!playerTags) return message.reply({ embeds: [t]})
    const target = await message.mentions.members.first() || message.guild.members.cache.get(args[1])
     if (!target) return message.reply({ embeds: [embed1]})
     const reason = args.slice(2).join(" ")
     if (!reason) return message.reply({ embeds: [embed2]})
    async function fetchData(playerTags) {
        await coc.login({ email: process.env.email, password: process.env.password });
          const player = await coc.getPlayer(playerTags);
          const embed3 = new EmbedBuilder()
.setDescription(`<a:tdot:1039755764295798824> **${player.name} ${player.tag}**\n\n [𝗖𝗵𝗼𝗰𝗼𝗹𝗮𝘁𝗲 𝗖𝗹𝗮𝘀𝗵 𝗟𝗶𝗻𝗸](https://fwa.chocolateclash.com/cc_n/member.php?tag=${player.tag.replaceAll('#', '')})\n\n**__𝐑𝐞𝐚𝐬𝐨𝐧__** :-  \`${reason}\``)
.setColor('#44d4db')
await channel.send({ embeds: [embed3]})
          return [
            player.name, player.townHallLevel
          ]
        };
     try{
      const discordRoles = {
          'leader': '1030004171975442443',
                'coLeader': '1030004172952711178',
                'elder': '1030004173535711242',
              'member': '1030004174148087878',
              '#9JUVCV0L': '1035222919225286736',
              '#PCCJUVJQ': '1035223069637226607',
              '#GGUR2Y2': '1035223181419626579',
  '#PQP2Y2QV' : '1049743057563680829',
    };
    for (let index = 0; index < playerTags.length; index++) {
      const playerTag = playerTags[index];
      const playerData = await fetchData(playerTag);

      const clanPositionRole = await message.guild.roles.fetch(
          discordRoles[(playerData[2])],
      );
      const clanRole = await message.guild.roles.fetch(
          discordRoles[(playerData[3])],
      );
      await target.roles.remove(clanRole);
      await target.roles.remove(clanPositionRole);
    };
    
      const playerData = await fetchData(playerTags[0]);
      const villageName = playerData[0];

    let ole = message.guild.roles.cache.find(r => r.id === config.unq);

  await target.roles.add(ole);
 await target.setNickname(` UQ - ${villageName}`);

const re = await client.channels.fetch(config.unqualifiedID, { force: false });
if (!re) {
    return;
}
const b = new EmbedBuilder()
.setColor('#44d4db')
.setFooter( {
  text: `JPA - 💎FWA💎`
})
.setDescription(`𝗧𝗵𝗶𝘀 𝗶𝘀 <#1044111604402376804> room. 𝗬𝗼𝘂'𝗿𝗲 𝗵𝗲𝗿𝗲 𝗯𝗲𝗰𝗮𝘂𝘀𝗲 :-\n\n<a:dots:1044176156900982794>You either left the clan or got kicked out from clan due to **inactivity/deviating from rules/or exceeding the minimum set strike points**.\n<a:dots:1044176156900982794>You will be allowed to apply back after **a week** from today.\n\n<a:hashtag:1046452309858721892>Please type  \`!apply\` and follow the steps if you wish to join back later, Ty!`)
   
await re.send({ content: `𝗣𝗹𝗲𝗮𝘀𝗲 𝗿𝗲𝗮𝗱 𝘁𝗵𝗲 𝗶𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 𝗯𝗲𝗹𝗼𝘄 ${target}` ,embeds: [b], ephemeral: false});
     }catch (error) {
      console.log(error);
    }
}
};
