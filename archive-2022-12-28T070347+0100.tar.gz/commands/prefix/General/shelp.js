const { EmbedBuilder } = require("discord.js");
const fs = require('fs');

module.exports = {
  config: {
    name: "shelp",
    description: "Replies with Staff help menu.",
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix) => {
    const commands = client.prefix_commands.map(command => `${prefix}${command.config.name}`);
  const a = new EmbedBuilder()
    .setColor('#44d4db')
    .setFooter( {
      text: `JPA - 💎FWA💎`
  })
  .setDescription (`<a:hashtag:1046452309858721892>  List of the currently accessible commands of prefix. 
  <a:SC_Point:1051709557157658644> Regarding 𝐅𝐖𝐀 Base Layout - \`${prefix}base\`
  <a:SC_Point:1051709557157658644> To determine if a war is 𝐖𝐢𝐧 or 𝐋𝐨𝐬𝐞. - \`${prefix}point <clancode> \`
  <a:SC_Point:1051709557157658644> Information Regarding 𝐅𝐖𝐀 - \`${prefix}fwa | faq\``)
 
  const b = new EmbedBuilder()
  .setColor('#44d4db')
  .setFooter( {
    text: `JPA - 💎FWA💎`
})
.setDescription (`<a:hashtag:1046452309858721892>  List of the currently accessible commands of prefix. 
<a:SC_Point:1051709557157658644> Player Verification Using 𝐂𝐡𝐨𝐜𝐨𝐥𝐚𝐭𝐞𝐜𝐥𝐚𝐬𝐡 Link - \`${prefix}p <playerIdTag>\`
<a:SC_Point:1051709557157658644> Clan Verification Using 𝐂𝐡𝐨𝐜𝐨𝐥𝐚𝐭𝐞𝐜𝐥𝐚𝐬𝐡 Link - \`${prefix}c <clanIdTag>\`
<a:SC_Point:1051709557157658644> To 𝐀𝐜𝐜𝐞𝐩𝐭 Player - \`${prefix}app <playertag> <@mentionuser>\`
<a:SC_Point:1051709557157658644> To 𝐑𝐞𝐣𝐞𝐜𝐭 a player - \`${prefix}unq <playertag> <@mentionuser>\`
<a:SC_Point:1051709557157658644> To 𝐑𝐞𝐦𝐨𝐯𝐞 a player - \`${prefix}ex <playertag> <@mentionuser> <reason>\`
 `)
 const c = new EmbedBuilder()
 .setColor('#44d4db')
 .setFooter( {
   text: `JPA - 💎FWA💎`
})
.setDescription (`<a:hashtag:1046452309858721892> List of the currently accessible commands of Slash Command. 
<a:SC_Point:1051709557157658644> Clan Role 𝐀𝐬𝐬𝐢𝐠𝐧𝐦𝐞𝐧𝐭 - \`/as <@mentionuser> <playertag>\`
`)
 await  message.channel.send({ content: `  <a:arrow1:1051709278907535380> **for All**` ,embeds: [a], ephemeral: false});
 await message.channel.send({ content: `<a:arrow1:1051709278907535380> **Only for Staff**` ,embeds: [b], ephemeral: false});
 await message.channel.send({ content: `<a:arrow1:1051709278907535380> **Only for Staff**` ,embeds: [c], ephemeral: false});

  },
};