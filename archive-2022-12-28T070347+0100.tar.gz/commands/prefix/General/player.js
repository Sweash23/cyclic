const { EmbedBuilder } = require('discord.js');
const { Client, HTTPError , Util  } = require('clashofclans.js');
const coc = new Client();
module.exports = {
    config: {
        name: "p", 
        description: "Check Player profile using cc link ", 
    },
    permissions: "SendMessages",
    owner: false, 
    run: async (client, message, args, prefix, config, db) => {
  
        (async function () {
              await coc.login({ email: process.env.email, password: process.env.password });
                 let playerTag = args[0];
        if (!playerTag) {
          return message.reply({
                content:
                    "You need to provide Player Tag",
                ephemeral: true
            });
        } else if (!Util.isValidTag(Util.formatTag(playerTag))) {
          return message.reply({ content: `${playerTag} isn't a valid player tag!`, ephemeral: false });
    } 

        const player = await coc.getPlayer(playerTag);
 try {
    await message.reply({ embeds: [
        new EmbedBuilder()
        .setTitle(`**${player.name}**`)
        .setColor('DarkButNotBlack')
        .setFooter( {
          text: `JPA - 💎FWA💎`
       })
       .setThumbnail(player.league.icon.url)
     .setDescription(`
==== **Profile Info** ====
Tag: [**${player.tag}**](https://link.clashofclans.com/en?action=OpenPlayerProfile&tag=${player.tag.replaceAll('#', '')})
Clan: **${player.clan?.name || 'None' } ${player.clan?.tag || ''}**
Role: **${config.r[player.role]}**
${config.townhallE[player.townHallLevel]}${config.townhallW[player.townHallWeaponLevel]}\   <:experience:1038075821514051666> ${player.expLevel}\   <:star:1039734175739170848> ${player.warStars}
<a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836>
<a:izkdot:1039755736999276654>**Season Stats:**
**-** __Attacks__
${config.lemoji[player.league.name] } Trophies: ${player.trophies}
<:Attack:1038076515784601661> Attack Wins: ${player.attackWins}
<:Defense:1038076922460110890> Defense Wins: ${player.defenseWins}
<a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836>
**-** __Donations__
<a:waup:1039755754665693224> Donated: ${player.donations}
<a:wadown:1039755748881735681> Received: ${player.received}
<a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836>
<a:izkdot:1039755736999276654> **Achievement Stats:**
<:TD:1057309243247697970> Total Donations: **${player.achievements.at(14).value}**
<:trophy:1039734188166877204> Best Trophies: **${player.achievements.at(7).value}**
<:ClanGames:1057305630559457310> Clan Games: **${player.achievements.at(31).value}**
<:sw:1057308422401437808> CG Raided: **${player.achievements.at(41).value}**
<:capitalgold:1039734136816025682> CG Donated: **${player.achievements.at(42).value}**
<a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836><a:lines:1049699649411362836>
<a:fwa:1037968348828409866> [𝗖𝗵𝗼𝗰𝗼𝗹𝗮𝘁𝗲 𝗖𝗹𝗮𝘀𝗵 𝗟𝗶𝗻𝗸](https://fwa.chocolateclash.com/cc_n/member.php?tag=${player.tag.replaceAll('#', '')})
`)],
      })
   } catch{
        await message.reply({ content: 'Something went wrong, try again!' });
    }

        })();
    }
};