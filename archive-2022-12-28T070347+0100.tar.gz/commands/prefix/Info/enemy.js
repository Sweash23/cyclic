const { EmbedBuilder } = require("discord.js"); 

module.exports = {
  config: {
    name: "enemy",
    description: "INFO on FWA enemy!",
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {

    message.reply({ embeds: [
                new EmbedBuilder()
              .setColor('DarkAqua')
              .setDescription(`<a:info:1035884514007842826>【𝐈𝐍𝐅𝐎 𝐅𝐎𝐑 𝐄𝐍𝐄𝐌𝐘】\n\n<a:izkdot:1039755736999276654>We will let you win! All we ask is that you leave as many Town Hall and storages outside your defenses as possible. The idea is that this is a win-win system with YOUR clan as the big winner. You will add another war win to your war stats, have all of our loot and the full war bonus. You are very likely to do this with a minimum amount of troops spent.\n\n<a:izkdot:1039755736999276654> You never lose any loot during a war as it is commonly known that the loot reflected within the storages during war is just a nice free gift from SuperCell, so you don’t really lose anything by giving it to us. We will receive the war bonus loot for successful attack and the loot within the storages from SuperCell that you help us receive by exposing your Town Halls and storages on your top villages. Our war bonus will only be 40% of what you get, but we will gladly receive the additional clan xp, stars and loot. Since we war almost all the time it will still be beneficial for us. It is important for us that YOU win the war!\n\n<a:izkdot:1039755736999276654> Clan Castle Troops: This is just another great thing when you war against us. You are sure to win even if you don’t spend a lot of time and resources to fill up your war clan castle troops. It will make it more profitable for your guys, and easier for us.\n\n<a:izkdot:1039755736999276654> Clan experience (XP): We ask for you to put out the Town Hall and storages. This will enable us to do more attacks on your villages to gain extra Clan XP. We will carefully watch the amount of stars you make so we never get ahead of you. You will always win the war! Feel free to visit our clan before the war starts to check out our war statistics if you are unsure about our system.\n\n<a:amar:1039222542591873165> [LEARN MORE](https://farmwaralliance.org/)`)
              .setFooter( {
                text: `◤ 𝗝𝗣𝗔 ◢ - 💎𝗙𝗪𝗔💎`
            })
            ],
            ephemeral: true
     })
    
  },
};