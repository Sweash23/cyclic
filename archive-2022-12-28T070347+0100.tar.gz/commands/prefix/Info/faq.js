const { EmbedBuilder } = require("discord.js"); 

module.exports = {
  config: {
    name: "faq",
    description: "FREQUENTLY ASKED QUESTIONS!",
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {

    message.reply({ embeds: [
                new EmbedBuilder()
              .setColor('Gold')
              .setDescription(`<a:info:1035884514007842826>【𝐅𝐑𝐄𝐐𝐔𝐄𝐍𝐓𝐋𝐘 𝐀𝐒𝐊𝐄𝐃 𝐐𝐔𝐄𝐒𝐓𝐈𝐎𝐍𝐒】`)
              .addFields(
                { name: 'Q: Which clan takes the win?', value: 'A: FWA has a unique points system that determines who takes the win between the two clans:\n<a:sparkle:1039755777272987738> [【𝐂𝐋𝐈𝐂𝐊 𝐇𝐄𝐑𝐄】](https://tiny.cc/FWApoints)'},
                { name: 'Q: Do you always match another FWA clan?', value: 'A: Provided your clan’s weight, composition and war start time is done correctly, 96% of the time your clan will be matched with another FWA clan.'},
                { name: 'Q: How do I know if a clan is FWA?', value: 'A: All FWA clans have their location set to Lesotho and “💎FWA💎” somewhere in their description. Also, there is an official list of all FWA clans:\n<a:sparkle:1039755777272987738> [【𝐂𝐋𝐈𝐂𝐊 𝐇𝐄𝐑𝐄】](https://tinyfwa.com/FWAproud)'},
                { name: 'Q: How much loot do you get?', value: 'A: The losing clan takes 40% of the war win bonus while the winning clan takes 100% of the bonus. An average player will take home about 2 million gold and elixir and 10k dark elixir on a winning war. On a losing war, an average player can take around 500k gold and elixir and 2.5k dark elixir. Clan level and player TH have an impact in these numbers'},
                { name: 'Q: How should my FWA base look?', value: 'A: The buildings should be separated from all defenses and traps. Tutorial and screenshots of how your base should look are here:\n<a:sparkle:1039755777272987738> [【𝐂𝐋𝐈𝐂𝐊 𝐇𝐄𝐑𝐄】](https://www.farmwaralliance.org/base-design)'},
              )
              .setFooter( {
                text: `◤ 𝗝𝗣𝗔 ◢ - 💎𝗙𝗪𝗔💎`
            })
            ],
            ephemeral: true
     })
    
  },
};