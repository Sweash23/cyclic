const { EmbedBuilder } = require("discord.js"); 

module.exports = {
  config: {
    name: "point",
    description: "Point Of clans",
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {
        if(!args[0]) return message.reply(`please provide clan Code **jc | pb | av | 1e**`);

    if(args[0] == 'jc') return message.reply({ embeds: [
      new EmbedBuilder()
    .setColor(0x0099FF)
    .setDescription ('<a:right:1035795975039619124> 𝐉𝐎𝐇𝐍 𝐂𝐄𝐍𝐀 \n\n <a:points_1:1038677668218032168> [𝐂𝐋𝐈𝐂𝐊 𝐇𝐄𝐑𝐄](https://points.fwa.farm/result.php?clan=9JUVCV0L) \n\n ◤ 𝗝𝗣𝗔 ◢ - 💎𝗙𝗪𝗔💎')
  ],
  ephemeral: false
});
	else if(args[0] == 'pb' ) return message.reply({ embeds: [
      new EmbedBuilder()
    .setColor(0x0099FF)
    .setDescription('<a:right:1035795975039619124> 𝗽𝗹𝗮𝘆𝘆𝗯𝗼𝘆𝘀♥️ \n\n <a:points_1:1038677668218032168> [𝐂𝐋𝐈𝐂𝐊 𝐇𝐄𝐑𝐄](https://points.fwa.farm/result.php?clan=PCCJUVJQ) \n\n ◤ 𝗝𝗣𝗔 ◢ - 💎𝗙𝗪𝗔💎')
  ],
  ephemeral: false
}); 
		else if(args[0] == 'av') return message.reply({ embeds: [
      new EmbedBuilder()
    .setColor(0x0099FF)
    .setDescription ('<a:right:1035795975039619124> 【﻿𝐀𝐯𝐞𝐧𝐠𝐞𝐫𝐒.】 \n\n <a:points_1:1038677668218032168> [𝐂𝐋𝐈𝐂𝐊 𝐇𝐄𝐑𝐄](https://points.fwa.farm/result.php?clan=GGUR2Y2) \n\n ◤ 𝗝𝗣𝗔 ◢ - 💎𝗙𝗪𝗔💎')
  ],
  ephemeral: false
});
else if(args[0] == '1e') return message.reply({ embeds: [
  new EmbedBuilder()
.setColor(0x0099FF)
.setDescription ('<a:right:1035795975039619124> #𝟏 𝐄𝐥𝐢𝐭𝐞 \n\n <a:points_1:1038677668218032168> [𝐂𝐋𝐈𝐂𝐊 𝐇𝐄𝐑𝐄](https://points.fwa.farm/result.php?clan=PQP2Y2QV) \n\n ◤ 𝗝𝗣𝗔 ◢ - 💎𝗙𝗪𝗔💎')
],
ephemeral: false
});
	}

};