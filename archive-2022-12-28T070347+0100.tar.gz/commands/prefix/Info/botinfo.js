const { EmbedBuilder } = require("discord.js"); 
const moment = require("moment");
require("moment-duration-format");

module.exports = {
  config: {
    name: "stats",
    description: "INFO on Status of Bot!",
  },
  permissions: ['SendMessages'],
  owner: false,
  run: async (client, message, args, prefix, config, db) => {
    const duration = moment.duration(client.uptime).format(" D [days], H [hrs], m [mins], s [secs]");
  //  const sysDuration = moment.duration(os.uptime()*1000).format("D[d] H[h] m[m] s[s]");
    message.reply({ embeds: [
                new EmbedBuilder()
              .setColor(0x0099FF)
	.setTitle(client.user.tag)
    .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }))
    .setDescription(`**
    • User Count: \`${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)}\`
    • Server Count: \`${client.guilds.cache.size}\`
    • Channel Count: \`${client.channels.cache.size}\`
    • Connected Voice: \`${client?.voice?.adapters?.size || 0}\`
    • Node.js Version: \`${process.version}\`
    • Operation Time: <t:${Math.floor(Number(Date.now() - client.uptime) / 1000)}:R>
    • UpTime: \`${duration}\`
    • Ping: \`${client.ws.ping} MS\`
    • Memory Usage: \`${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB\`
    • OS: \`${process.platform}\`
    **`)
	.setTimestamp()
],
            ephemeral: true
     })
    
  },
};