const { EmbedBuilder} = require('discord.js');
const {Client: ClashClient, HTTPError, Util} = require('clashofclans.js');

const clashClient = new ClashClient();
async function fetchData(playerTag) {
    await clashClient.login({ email: process.env.email, password: process.env.password });
  
    const targetPlayer = await clashClient.getPlayer(playerTag);
  
    return [
      targetPlayer.name, targetPlayer.townHallLevel,
      targetPlayer.role, targetPlayer.clan.tag,
    ];
  };
  
  function extractInfo(optionContent) {
    const tagArray = optionContent.split(' ');
    return tagArray;
  };

module.exports = {
    name: "as", 
    description: "Assign Clan role (note player should be in clan before using it)", 
    type: 1, 
    options: [
        {
            name: "target",
            description: "The member to be assigned",
            type: 6,
            required: true
        },
        {
            name: "tag",
            description: "The player tag(s)",
            type: 3,
            required: true
        },
    ],
    permissions: {
        DEFAULT_MEMBER_PERMISSIONS: "ManageRoles"
    },
    run: async (client, interaction, config, db) => {
            const target = await interaction.guild.members.fetch(
                (interaction.options.getUser('target')).id,
            );
            const playerTags = extractInfo(interaction.options.getString('tag'));

      await interaction.deferReply();
            const clanRoles = {
              '#9JUVCV0L': 'JC',
              '#PCCJUVJQ': 'PB',
              '#GGUR2Y2': 'AV',
              '#PQP2Y2QV': '1E',

            };
            const discordRoles = {
                'leader': '1030004171975442443',
                'coLeader': '1030004172952711178',
                'elder': '1030004173535711242',
              'member': '1030004174148087878',
              '#9JUVCV0L': '1035222919225286736',
              '#PCCJUVJQ': '1035223069637226607',
              '#GGUR2Y2': '1035223181419626579',
             '#PQP2Y2QV' : '1049743057563680829',
            };
       let ole = interaction.guild.roles.cache.find(r => r.id === config.unq);
       let le = interaction.guild.roles.cache.find(r => r.id === config.nc);
       let e = interaction.guild.roles.cache.find(r => r.id === config.app);
            const rolesToAdd = [];
            for (let index = 0; index < playerTags.length; index++) {
              const playerTag = playerTags[index];
              const playerData = await fetchData(playerTag);
      
              const clanPositionRole = await interaction.guild.roles.fetch(
                  discordRoles[(playerData[2])],
              );
              const clanRole = await interaction.guild.roles.fetch(
                  discordRoles[(playerData[3])],
              );
      
              rolesToAdd.push( clanPositionRole, clanRole);
            };
            const playerData = await fetchData(playerTags[0]);
            const villageName = playerData[0];
            const clanPosition = clanRoles[playerData[3]];
      
            target.setNickname(`${clanPosition} - ${villageName}`);
            await target.roles.add(rolesToAdd);

              await target.roles.remove(ole);
             await target.roles.remove(le);
             await target.roles.remove(e);
         
           const channel = await client.channels.fetch(config.ass, { force: false });
           if (!channel) {
               return;
           }

           const b = new EmbedBuilder()
    .setFooter( {
      text: `JPA - 💎FWA💎`
  })
  .setDescription(`<a:celebrationop:1048300662301151362> 𝗪𝗲𝗹𝗰𝗼𝗺𝗲 𝘁𝗼 𝘁𝗵𝗲 𝗝𝗣𝗔 𝗧𝗲𝗮𝗺.\n\n<a:cyan_arrow:1048293742127370320> Please make sure your FWA base is set active as war base and war shield is set to green.\n<a:cyan_arrow:1048293742127370320> For clan Rules :- Visit <#1035871505998958593> and click on to your respective clan rules.\n<a:cyan_arrow:1048293742127370320> Please do have a go through at <#1038407922029441085> for knowing the server.\n<a:bcube:1043956244467155066> Enjoy your stay <a:pepearmy:1048296080321806417>!`)
  .setColor('#00FFFF')
 
 await channel.send({ content: `Hey ${target}, 𝗣𝗹𝗲𝗮𝘀𝗲 𝗿𝗲𝗮𝗱 𝘁𝗵𝗲 𝗯𝗲𝗹𝗼𝘄.` ,embeds: [b], ephemeral: false});
//await interaction.reply({ content: `Assigned  ${target}`, ephemeral: true });
//await interaction.followUp;
await interaction.editReply(`Assigned  ${target}`)
 //await interaction.editReply ();

    },
};